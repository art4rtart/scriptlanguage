from distutils.core import setup, Extension
setup(name='SeoulSubway',
version='1.0', py_modules=['sub'],
)

